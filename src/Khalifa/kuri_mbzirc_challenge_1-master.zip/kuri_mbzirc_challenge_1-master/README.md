# kuri_mbzirc_challenge_1
Challenge 1 related tasks implementation
